function analyzeNews() {

    const text =
        document.getElementById("article")
        .value
        .toLowerCase();

    const positive = [
        "success", "growth", "benefit",
        "improve", "positive"
    ];

    const negative = [
        "crisis", "danger", "failure",
        "attack", "problem"
    ];

    let p = 0;
    let n = 0;

    positive.forEach(word => {
        if (text.includes(word)) p++;
    });

    negative.forEach(word => {
        if (text.includes(word)) n++;
    });

    let sentiment;

    if (p > n) {
        sentiment = "Positive";
    } else if (n > p) {
        sentiment = "Negative";
    } else {
        sentiment = "Neutral";
    }

    const words =
        text.trim() === ""
            ? 0
            : text.trim().split(/\s+/).length;

    document.getElementById("sentiment").innerText =
        "Sentiment: " + sentiment;

    document.getElementById("emotion").innerText =
        "Emotional Words: " + (p + n);

    document.getElementById("length").innerText =
        "Word Count: " + words;
}